package RegrasSintaticas;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import Analisador.ControleSintatico;

public interface RegrasSintaticas {
	
	ControleSintatico objControle = new ControleSintatico();
	Multimap<String, Integer> VerificaChaves = LinkedHashMap.create();
	
	boolean verificar(ArrayList<ControleSintatico> VetorAnaliseLexica);
}
