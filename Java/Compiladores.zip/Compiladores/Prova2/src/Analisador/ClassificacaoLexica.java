package Analisador;

public record ClassificacaoLexica(String lexema, Token token, int linha) {	
}
